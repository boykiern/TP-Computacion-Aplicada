#!/bin/bash

if [ "$1" = "-help" ]; then
    echo "Uso: backup_full.sh ORIGEN DESTINO"
    echo "Ejemplo: backup_full.sh /var/log /backup_dir"
    exit 0
fi

if [ $# -ne 2 ]; then
    echo "Error: cantidad de argumentos incorrecta."
    echo "Use: backup_full.sh -help"
    exit 1
fi

ORIGEN=$1
DESTINO=$2
FECHA=$(date +%Y%m%d)
NOMBRE=$(basename "$ORIGEN")
ARCHIVO="backup_${NOMBRE}_${FECHA}.tar.gz"

if [ ! -d "$ORIGEN" ]; then
    echo "Error: el directorio de origen no existe."
    exit 1
fi

if [ ! -d "$DESTINO" ]; then
    echo "Error: el directorio de destino no existe."
    exit 1
fi

tar -czf "$DESTINO/$ARCHIVO" "$ORIGEN"

echo "Backup creado correctamente en $DESTINO/$ARCHIVO"
