history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
hostnamect1 set-hostname TPServer
hostnamect1
hostnamectl set-hostname TPServer
hostnamectl
cat /etc/hostname
nano /etc/hosts
nano /etc/hosts
nano/etc/hosts
cat /etc/hosts
cp /etc/hosts /etc/hosts.bkp
sed -i 's/debian/TPServer/g' /etc/hosts
cat /etc/hosts
reboot
hostnamectl
cat /etc/debian_version
cat /etc/os-release
ip a
ping -c 3 8.8.8.8
ping -c 3 deb.debian.org
apt update
apt upgrade
upt update
apt update
cat /etc/apt/sources.list
cp /etc/apt/sources.list /etc/apt/sources.list.bkp
loadkeys la-latin1
loadkeys es
loadkeys us
cp /etc/apt/sources.list /etc/apt/sources.list.bkp
sed -i 's/cdn2-fastly.deb.debian.org/deb.debian.org/g' /etc/apt/sources.list
sed -i '3c deb http://security.debian.org/debian-security bullseye-security main contrib non-free' /etc/apt/sources.list
cat /etc/apt/sources.list
apt update
apt upgrade
apt autoremove
apt update
vi /etc/apt/sources.list
cat /etc/apt/sources.list
apt update
apt full-upgrade
apt update
apt full-upgrade
reboot
cat /etc/debian_version
cat /etc/os-release
shotdown -h now
poweroff
exit
ls -la /root
tar -tzf /root/Material_Adicional_TPVMCA.tar.gz
tar -xzf /root/Material_Adicional_TPVMCA.tar.gz
ls -la
pwd
ls -la
ls -la Material_Adicional_TPVMCA
ls -la Material_Adicional_TPVMCA
cp Material_Adicional_TPVMCA/* /root/
pwd
ls -la
ls -la /root
apt-get install openssh-server
service ssh status
mkdir -p /root/.ssh
cp /root/clave_publica.pub /root/.ssh/authorized_keys
chmod 700 /root/.ssh
chmod 600 /root/.ssh/authorized_keys
vi /etc/ssh/sshd_config
service ssh restart
service ssh status
ip a
apt-get install apache2 mariadb-server php libapache2-mod-php php-mysql
service apache2 status
service mariadb status
ip a
ls -la /root/index.php /root/logo.png
cp /root/index.php /var/www/html/
cp /root/logo.png /var/www/html/
ls -la /var/www/html/
service apache2 status
ls -la /var/www/html/
ls -la /var/www/html
cat /root/index.php
mysql < /root/db.sql
service mariadb restart
service apache2 restart
php -v
mysql
ip a
ip a
clear
ip a
ip route
cat /etc/network/interfaces
cp /etc/network/interfaces /etc/network/interfaces.bkp
vi /etc/network/interfaces
cat /etc/network/interfaces
systemctl restart networking
systemctl status networking.service
ip a
vi /etc/network/interfaces
ifup enp0s3
ip a
ip route
ping -c 3 8.8.8.8
ping -c 3 deb.debian.org
shutdown -h now
lsblk
cat /proc/partitions
fdisk /dev/sdc
lsblk
mkfs.ext4 /dev/sdc1
mkfs.ext4 /dev/sdc2
lsblk -f
mkdir /www_dir
mkdir /backup_dir
mount /dev/sdc1 /www_dir
mount /dev/sdc2 /backup_dir
lsblk
blkid /dev/sdc1 /dev/sdc2
cp /etc/fstab /etc/fstab.bkp
vi /etc/fstab
mount -a
blkid /dev/sdc1 /dev/sdc2
cat /etc/fstab
vi /etc/fstab
systemctl daemon-reload
mount -a
lsblk
mkdir -p /opt
cat /proc/partitions > /opt/particion
cat /opt/particion
reboot
mkdir -p /opt/scripts
cat > /opt/scripts/backup_full.sh << 'EOF'
#!/bin/bash

if [ "$1" = "-help" ]; then
    echo "Uso: backup_full.sh ORIGEN DESTINO"
    echo "Ejemplo: backup_full.sh /var/log /backup_dir"
    exit 0
fi

if [ $# -ne 2 ]; then
    echo "Error: cantidad de argumentos incorrecta."
    echo "Use: backup_full.sh -help"
    exit 1
fi

ORIGEN=$1
DESTINO=$2
FECHA=$(date +%Y%m%d)
NOMBRE=$(basename "$ORIGEN")
ARCHIVO="backup_${NOMBRE}_${FECHA}.tar.gz"

if [ ! -d "$ORIGEN" ]; then
    echo "Error: el directorio de origen no existe."
    exit 1
fi

if [ ! -d "$DESTINO" ]; then
    echo "Error: el directorio de destino no existe."
    exit 1
fi

tar -czf "$DESTINO/$ARCHIVO" "$ORIGEN"

echo "Backup creado correctamente en $DESTINO/$ARCHIVO"
EOF

